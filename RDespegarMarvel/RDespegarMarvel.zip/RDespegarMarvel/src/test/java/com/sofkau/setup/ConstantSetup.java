package com.sofkau.setup;
public class ConstantSetup {
    public static final String DESPEGAR_URL="https://www.despegar.com.co/";
}
